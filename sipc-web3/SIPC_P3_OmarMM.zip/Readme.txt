PRÁCTICA 3 SIPC - OMAR MENDO MESA

i) He tenido que rediseñar desde cero la página, ya que existian muchos problemas a la hora de indexar Firebase y el chat en la página web, por
   lo que he decidido realizar la página a partir de una plantilla que he encontrado.

ii)Se ha indexado también AngularJS, además de utilizar NodeJS y Firebase
